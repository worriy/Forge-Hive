
namespace Hive.Backend.Models
{
    public enum CardTypes
    {
        Reporting,
        Idea,

        Mood,
        Quote,
        Suggestion
    }
}

