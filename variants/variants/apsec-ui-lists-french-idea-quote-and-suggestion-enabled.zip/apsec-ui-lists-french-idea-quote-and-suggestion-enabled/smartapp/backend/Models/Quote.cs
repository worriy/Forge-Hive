
namespace Hive.Backend.DataModels
{
    public class Quote : Card
    {
        public Quote() : base()
        {

        }
    }
}

