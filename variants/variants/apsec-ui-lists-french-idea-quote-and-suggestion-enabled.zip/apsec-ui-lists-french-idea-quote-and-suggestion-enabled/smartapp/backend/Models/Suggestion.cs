
namespace Hive.Backend.DataModels
{
    public class Suggestion : Card
    {
        public Suggestion() : base()
        {

        }
    }
}

