﻿
namespace Hive.Backend.ViewModels
{
    public class GeneralMoodVM
    {
        public GeneralMoodVM()
        {
        }

        public string MoodName { get; set; }
        public int Value { get; set; }
    }
}
