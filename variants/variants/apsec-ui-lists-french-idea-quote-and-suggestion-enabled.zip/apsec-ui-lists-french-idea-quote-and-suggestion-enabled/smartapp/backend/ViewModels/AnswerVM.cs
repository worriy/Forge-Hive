
namespace Hive.Backend.ViewModels
{
    public partial class AnswerVM
    {
        public string IdUser { get; set; }
        public string IdCard { get; set; }
        public string IdChoice { get; set; }

    }
}