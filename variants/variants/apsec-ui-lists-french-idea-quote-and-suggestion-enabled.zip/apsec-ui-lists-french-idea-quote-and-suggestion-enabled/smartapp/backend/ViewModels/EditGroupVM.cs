using System;
using Hive.Backend.DataModels;

namespace Hive.Backend.ViewModels
{
	public partial class EditGroupVM 
	{
		public string Name  { get; set; }
		public string City  { get; set; }
		public string Country  { get; set; }
		public string Id  { get; set; }

			
	}
}