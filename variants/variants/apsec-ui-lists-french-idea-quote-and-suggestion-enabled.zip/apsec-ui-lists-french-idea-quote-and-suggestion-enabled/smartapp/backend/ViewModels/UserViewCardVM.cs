
namespace Hive.Backend.ViewModels
{
	public partial class UserViewCardVM 
	{
		public UserViewCardVM() 
		{
		}

		public string CardId  { get; set; }
		public string UserId  { get; set; }
			
	}
}