
namespace Hive.Backend.ViewModels
{
	public partial class PictureVM 
	{
		public PictureVM() 
		{
		}

		public string Picture  { get; set; }
	}
}