export interface UpdateProfilePicture {
  userProfileId: string;
  
  picture: string;
}
