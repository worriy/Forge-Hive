export interface UserUpdate {
  id: string;
  email: string;

  firstName: string;

  lastName: string;

  phoneNumber: string;

  city: string;

  country: string;

  department: string;
  
  job: string;
}
