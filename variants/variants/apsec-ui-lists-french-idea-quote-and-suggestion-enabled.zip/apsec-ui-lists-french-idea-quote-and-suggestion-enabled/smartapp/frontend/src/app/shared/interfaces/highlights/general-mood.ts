export interface GeneralMood {
  moodName: string;

  value: number;
}
