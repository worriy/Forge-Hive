export enum CardTypes {
  Reporting,
  Idea,
  
  
  Mood,
  Quote,
  Suggestion
};

