import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MoodCardComponent } from './components/mood-card/mood-card.component';
import { QuoteCardComponent } from './components/quote-card/quote-card.component';
import { TranslateModule } from '@ngx-translate/core';
import { IdeaCardComponent } from './components/idea-card/idea-card.component';

import { ReportingCardComponent } from './components/reporting-card/reporting-card.component';
import { SuggestionCardComponent } from './components/suggestion-card/suggestion-card.component';




@NgModule({
  declarations: [
    IdeaCardComponent,
    
    ReportingCardComponent,
    SuggestionCardComponent,
    
    MoodCardComponent,
    QuoteCardComponent
  ],
  imports: [
    CommonModule,
    TranslateModule.forChild()
  ],
  exports: [
    IdeaCardComponent,
    
    ReportingCardComponent,
    SuggestionCardComponent,
    
    MoodCardComponent,
    QuoteCardComponent
  ]
})
export class SharedModule { }

