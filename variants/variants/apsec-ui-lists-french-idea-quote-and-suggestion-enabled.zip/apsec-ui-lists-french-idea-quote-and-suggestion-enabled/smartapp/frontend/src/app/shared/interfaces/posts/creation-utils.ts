import { TargetGroup } from "../groups/target-group";

export interface CreationUtils {
  targets?: string;
  pictureSelected?: boolean;
}