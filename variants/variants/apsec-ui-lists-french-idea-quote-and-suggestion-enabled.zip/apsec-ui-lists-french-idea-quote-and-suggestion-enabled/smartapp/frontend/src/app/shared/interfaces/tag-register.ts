export interface TagRegister {
  installationId: string;

  registrationId: string;

  tags: string[];

  platform: string;
}
