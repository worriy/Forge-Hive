export interface FullUser {
  firstname: string;

  lastname: string;

  phoneNumber: string;

  email: string;

  country: string;

  city: string;

  department: string;

  job: string;
  
  userProfileId: string;
}
