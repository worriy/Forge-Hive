export interface UpdateMembers {
  userIds: string[];

  groupId: string;
}
