export interface Group {
  idGroup: string;

  name: string;

  numberMembers: number;

  city: string;

  country: string;

  createdbyId: number;

  isAuthor: boolean;
}