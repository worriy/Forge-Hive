export interface User {
  firstname: string;

  lastname: string;

  picture: string;

  email: string;

  job: string;
  
  userProfileId: string;
}
