export interface UserProfile {
  id: string;
  
  applicationUserId: string;

  job: string;

  department: string;

  city: string;

  country: string;

  pictureId: string;
}
