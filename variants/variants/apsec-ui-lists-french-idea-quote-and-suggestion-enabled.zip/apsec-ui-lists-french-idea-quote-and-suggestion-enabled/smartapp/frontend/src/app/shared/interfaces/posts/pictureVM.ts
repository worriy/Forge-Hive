export interface PictureVM {
  picture: string;
}
