export interface UserViewCard {
  cardId: string;
  
  userId: string;
}
