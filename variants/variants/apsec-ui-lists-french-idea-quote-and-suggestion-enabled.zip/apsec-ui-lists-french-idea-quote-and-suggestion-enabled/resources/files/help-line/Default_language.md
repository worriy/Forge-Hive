# Default Applciation Language

***Choose your default application language***

---

The ***Default Language*** is the ***Language*** that end-users see in your application by default. You can choose a ***Default Language*** by the majority tongue ***language*** for the target users.

---
